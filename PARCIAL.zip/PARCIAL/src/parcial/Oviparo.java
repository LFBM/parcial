/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial;

/**
 *
 * @author Felipe
 */
public class Oviparo extends Animal{
    
    
    public void ponerHuevos(){
        System.out.println("Animales que nacen de un huevo");
    }
    
    
    
}
